
import { GameState, GameEventEffect, SubjectId, RelationshipId, ItemId } from '../types';
import { clamp } from '../utils/common';
import { formatEffect } from '../utils/logFormatter';
import { LOG_TEMPLATES } from '../data/constants/logMessages';

/**
 * 複数の効果オブジェクトを合成する
 */
export const mergeEffects = (base: GameEventEffect, ...others: (GameEventEffect | undefined)[]): GameEventEffect => {
  // Deep clone base to avoid mutation issues, simplistic approach
  const result: GameEventEffect = JSON.parse(JSON.stringify(base));

  others.forEach(other => {
    if (!other) return;

    if (other.hp) result.hp = (result.hp || 0) + other.hp;
    if (other.sanity) result.sanity = (result.sanity || 0) + other.sanity;
    if (other.money) result.money = (result.money || 0) + other.money;
    if (other.caffeine) result.caffeine = (result.caffeine || 0) + other.caffeine;

    if (other.knowledge) {
      result.knowledge = result.knowledge || {};
      Object.entries(other.knowledge).forEach(([k, v]) => {
        const sid = k as SubjectId;
        result.knowledge![sid] = (result.knowledge![sid] || 0) + (v || 0);
      });
    }

    if (other.relationships) {
      result.relationships = result.relationships || {};
      Object.entries(other.relationships).forEach(([k, v]) => {
        const rid = k as RelationshipId;
        result.relationships![rid] = (result.relationships![rid] || 0) + (v || 0);
      });
    }

    if (other.inventory) {
      result.inventory = result.inventory || {};
      Object.entries(other.inventory).forEach(([k, v]) => {
        const iid = k as ItemId;
        result.inventory![iid] = (result.inventory![iid] || 0) + (v || 0);
      });
    }

    if (other.buffs) {
      result.buffs = [...(result.buffs || []), ...other.buffs];
    }
  });

  return result;
};

/**
 * GameEventEffectをGameStateに適用する。
 * 更新されたStateと、フォーマット済みのログメッセージを返す。
 * Note: Stateは浅いコピーを作成して更新する（Immutabilityの確保）
 */
export const applyEffect = (
  state: GameState,
  effect: GameEventEffect
): { newState: GameState; messages: string[] } => {
  // 状態のコピー（ネストされたオブジェクトもコピー）
  const newState = {
    ...state,
    knowledge: { ...state.knowledge },
    relationships: { ...state.relationships },
    inventory: { ...state.inventory },
    activeBuffs: [...state.activeBuffs],
    flags: { ...state.flags } // flagsもコピー
  };

  const messages: string[] = formatEffect(effect);

  // --- 数値パラメータの更新 ---
  if (effect.hp) newState.hp = clamp(newState.hp + effect.hp, 0, newState.maxHp);
  if (effect.sanity) newState.sanity = clamp(newState.sanity + effect.sanity, 0, newState.maxSanity);
  if (effect.caffeine) newState.caffeine = clamp(newState.caffeine + effect.caffeine, 0, 200);

  // --- 知識パラメータの更新 ---
  if (effect.knowledge) {
    Object.entries(effect.knowledge).forEach(([key, val]) => {
      if (val) {
        const sId = key as SubjectId;
        newState.knowledge[sId] = clamp(newState.knowledge[sId] + val, 0, 100);
      }
    });
  }

  // --- 友好度の更新 ---
  if (effect.relationships) {
    Object.entries(effect.relationships).forEach(([key, val]) => {
      if (val) {
        const rId = key as RelationshipId;
        newState.relationships[rId] = clamp(newState.relationships[rId] + val, 0, 100);
      }
    });
  }

  // --- インベントリの更新 ---
  if (effect.inventory) {
    Object.entries(effect.inventory).forEach(([key, val]) => {
      if (val) {
        const iId = key as ItemId;
        const current = newState.inventory[iId] || 0;
        newState.inventory[iId] = Math.max(0, current + val);
      }
    });
  }

  // --- 所持金の更新 ---
  if (effect.money) {
    newState.money += effect.money;
  }

  // --- バフの適用 ---
  if (effect.buffs && effect.buffs.length > 0) {
    effect.buffs.forEach(buffData => {
      newState.activeBuffs.push({
        ...buffData,
        id: `BUFF_${state.turnCount}_${Math.random().toString(36).substr(2, 5)}`
      });
      messages.push(LOG_TEMPLATES.BUFF.DURATION(buffData.description, buffData.duration));
    });
  }

  return { newState, messages };
};
